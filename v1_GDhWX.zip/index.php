<?php
session_start();

// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'username');
define('DB_PASS', 'password');
define('DB_NAME', 'name');
define('DEEPSEEK_API_KEY', 'API');/*这里输入deep seek的api*/
define('DEEPSEEK_API_URL', 'https://api.deepseek.com/v1/chat/completions');
define('MODEL_NAME', 'deepseek-chat');
define('DEFAULT_TOKENS', 0); // 默认用户token限额

// 创建数据库连接
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 用户认证相关函数
function createTables($conn) {
    $tables = [
        "CREATE TABLE IF NOT EXISTS users (
            id INT AUTO_INCREMENT PRIMARY KEY,
            username VARCHAR(50) NOT NULL UNIQUE,
            password VARCHAR(255) NOT NULL,
            tokens INT DEFAULT " . DEFAULT_TOKENS . ",
            real_name_verified TINYINT(1) DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )",
        
        "CREATE TABLE IF NOT EXISTS token_usage (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            tokens_used INT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )",
        
        // 新增实名信息表
        "CREATE TABLE IF NOT EXISTS real_name_verification (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL UNIQUE,
            real_name VARCHAR(50) NOT NULL,
            id_card VARCHAR(18) NOT NULL UNIQUE,
            verified_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY (user_id) REFERENCES users(id)
        )"
    ];
    
    foreach ($tables as $sql) {
        if (!$conn->query($sql)) {
            error_log("创建表失败: " . $conn->error);
        }
    }
}

createTables($conn);

// 身份证验证函数
function validateIdCard($id_card) {
    // 基本格式验证
    if (!preg_match('/^\d{17}[\dX]$/i', $id_card)) {
        return false;
    }
    
    // 校验码验证
    $id_card = strtoupper($id_card);
    $factor = [7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2];
    $check_codes = ['1', '0', 'X', '9', '8', '7', '6', '5', '4', '3', '2'];
    
    $sum = 0;
    for ($i = 0; $i < 17; $i++) {
        $sum += $id_card[$i] * $factor[$i];
    }
    
    $mod = $sum % 11;
    return ($id_card[17] == $check_codes[$mod]);
}

// 处理用户登录/注册
if (isset($_POST['action'])) {
    switch ($_POST['action']) {
        case 'login':
            $username = $conn->real_escape_string($_POST['username']);
            $password = $_POST['password'];
            
            $sql = "SELECT id, password, tokens, real_name_verified FROM users WHERE username = '$username'";
            $result = $conn->query($sql);
            
            if ($result->num_rows === 1) {
                $user = $result->fetch_assoc();
                if (password_verify($password, $user['password'])) {
                    $_SESSION['user_id'] = $user['id'];
                    $_SESSION['username'] = $username;
                    $_SESSION['tokens'] = $user['tokens'];
                    $_SESSION['real_name_verified'] = $user['real_name_verified'];
                    echo json_encode(['success' => true]);
                    exit;
                }
            }
            echo json_encode(['error' => '用户名或密码错误']);
            exit;
            
        case 'register':
            $username = $conn->real_escape_string($_POST['username']);
            $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
            
            $sql = "INSERT INTO users (username, password) VALUES ('$username', '$password')";
            if ($conn->query($sql)) {
                $_SESSION['user_id'] = $conn->insert_id;
                $_SESSION['username'] = $username;
                $_SESSION['tokens'] = DEFAULT_TOKENS;
                $_SESSION['real_name_verified'] = 0; // 新用户未实名
                echo json_encode(['success' => true]);
                exit;
            }
            echo json_encode(['error' => '注册失败，用户名可能已被使用']);
            exit;
            
        case 'verify_real_name':
            if (!isset($_SESSION['user_id'])) {
                echo json_encode(['error' => '请先登录']);
                exit;
            }
            
            $user_id = $_SESSION['user_id'];
            $real_name = $conn->real_escape_string($_POST['real_name']);
            $id_card = $conn->real_escape_string($_POST['id_card']);
            
            // 验证身份证格式
            if (!validateIdCard($id_card)) {
                echo json_encode(['error' => '身份证号码格式不正确']);
                exit;
            }
            
            // 检查是否已实名
            $check_sql = "SELECT * FROM real_name_verification WHERE user_id = $user_id";
            $check_result = $conn->query($check_sql);
            if ($check_result->num_rows > 0) {
                echo json_encode(['error' => '您已完成实名认证，无需重复认证']);
                exit;
            }
            
            // 检查身份证是否已被使用
            $id_sql = "SELECT * FROM real_name_verification WHERE id_card = '$id_card'";
            $id_result = $conn->query($id_sql);
            if ($id_result->num_rows > 0) {
                echo json_encode(['error' => '该身份证号码已被使用']);
                exit;
            }
            
            // 插入实名信息（实际应用中应调用第三方实名认证API）
            $insert_sql = "INSERT INTO real_name_verification (user_id, real_name, id_card) 
                           VALUES ($user_id, '$real_name', '$id_card')";
            
            if ($conn->query($insert_sql)) {
                // 更新用户实名状态
                $update_sql = "UPDATE users SET real_name_verified = 1 WHERE id = $user_id";
                $conn->query($update_sql);
                $_SESSION['real_name_verified'] = 1;
                
                echo json_encode(['success' => true]);
                exit;
            }
            
            echo json_encode(['error' => '实名认证失败，请稍后再试']);
            exit;
    }
}

// 处理用户消息
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['message'])) {
    if (!isset($_SESSION['user_id'])) {
        echo json_encode(['error' => '请先登录']);
        exit;
    }
    
    $user_id = $_SESSION['user_id'];
    $user_tokens = $_SESSION['tokens'];
    
    // 检查是否完成实名认证
    if (!isset($_SESSION['real_name_verified']) || $_SESSION['real_name_verified'] == 0) {
        echo json_encode(['error' => '请先完成实名认证才能使用AI服务']);
        exit;
    }
    
    if ($user_tokens <= 0) {
        echo json_encode(['error' => '您的API调用额度已用完！']);
        exit;
    }
    
    $userMessage = trim($_POST['message']);
    
    if (!empty($userMessage)) {
        // 添加到对话历史
        if (!isset($_SESSION['chat_history'])) {
            $_SESSION['chat_history'] = [
                ['role' => 'system', 'content' => '你是一个乐于助人的AI助手，使用简洁、专业的语言回答用户问题']
            ];
        }
        
        // 添加用户消息
        $_SESSION['chat_history'][] = ['role' => 'user', 'content' => $userMessage];
        
        // 调用DeepSeek API
        $response = callDeepSeekAPI($_SESSION['chat_history']);
        
        // 添加AI回复
        if ($response) {
            $_SESSION['chat_history'][] = ['role' => 'assistant', 'content' => $response];
            
            // 减少用户tokens (这里简化处理，实际应从API响应获取token消耗)
            $tokens_used = min(100, $user_tokens); // 假设每次使用100 tokens
            $_SESSION['tokens'] -= $tokens_used;
        }
        
        // 检查用户剩余tokens
        $remaining_tokens = $_SESSION['tokens'];
        $token_warning = $remaining_tokens <= 100 ? "您的API调用额度仅剩{$remaining_tokens} tokens，请节约使用！" : "";
        
        // 返回JSON响应
        header('Content-Type: application/json');
        echo json_encode([
            'user_message' => $userMessage,
            'ai_response' => $response ? $response : '无法获取AI回复，请检查API配置',
            'timestamp' => date('H:i'),
            'remaining_tokens' => $remaining_tokens,
            'token_warning' => $token_warning
        ]);
        exit;
    }
}

// 开始新的对话
if (isset($_GET['new'])) {
    unset($_SESSION['chat_history']);
    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}

// 用户登出
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: '.$_SERVER['PHP_SELF']);
    exit;
}

// 调用DeepSeek API
function callDeepSeekAPI($messages) {
    $data = [
        'model' => MODEL_NAME,
        'messages' => $messages,
        'temperature' => 0.7,
        'max_tokens' => 1000
    ];
    
    $ch = curl_init(DEEPSEEK_API_URL);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
    curl_setopt($ch, CURLOPT_HTTPHEADER, [
        'Content-Type: application/json',
        'Authorization: Bearer ' . DEEPSEEK_API_KEY
    ]);
    
    $response = curl_exec($ch);
    $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
    
    if ($httpCode !== 200 || !$response) {
        error_log("DeepSeek API Error: " . curl_error($ch));
        return false;
    }
    
    curl_close($ch);
    
    $responseData = json_decode($response, true);
    
    if (isset($responseData['choices'][0]['message']['content'])) {
        return $responseData['choices'][0]['message']['content'];
    }
    return false;
}

function isUserLoggedIn() {
    return isset($_SESSION['user_id']) && !empty($_SESSION['user_id']);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>DeepSeek AI | 速科物联</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Poppins', 'Inter', 'Segoe UI', system-ui, -apple-system, sans-serif;
            -webkit-tap-highlight-color: transparent;
        }
        
        :root {
            --primary: #6366f1;
            --primary-gradient: linear-gradient(135deg, #6366f1, #8b5cf6);
            --primary-light: #e0e7ff;
            --primary-dark: #4f46e5;
            --secondary: #ec4899;
            --text: #1e293b;
            --text-light: #64748b;
            --text-lighter: #94a3b8;
            --bg: #f8fafc;
            --card-bg: rgba(255, 255, 255, 0.85);
            --card-border: rgba(255, 255, 255, 0.5);
            --shadow: 0 10px 25px rgba(0, 0, 0, 0.05);
            --border: rgba(226, 232, 240, 0.5);
            --ai-bubble: rgba(255, 255, 255, 0.95);
            --user-bubble: #6366f1;
            --success: #10b981;
            --error: #ef4444;
            --warning: #f59e0b;
            --radius: 16px;
            --glass-bg: rgba(255, 255, 255, 0.2);
            --glass-border: rgba(255, 255, 255, 0.3);
            --glass-shadow: 0 8px 32px rgba(31, 38, 135, 0.1);
        }
        
        body {
            background: linear-gradient(135deg, #e0e7ff, #ede9fe, #f0f9ff);
            min-height: 100vh;
            color: var(--text);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 20px;
            touch-action: manipulation;
            backdrop-filter: blur(10px);
        }
        
        .container {
            display: flex;
            flex-direction: column;
            width: 100%;
            max-width: 1200px;
            height: 90vh;
            background: var(--glass-bg);
            border-radius: var(--radius);
            box-shadow: var(--glass-shadow);
            overflow: hidden;
            position: relative;
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(10px);
        }
        
        /* 顶部导航栏 - 现代化设计 */
        .navbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 18px 25px;
            background: var(--glass-bg);
            border-bottom: 1px solid var(--glass-border);
            z-index: 10;
            backdrop-filter: blur(10px);
        }
        
        .brand {
            display: flex;
            align-items: center;
            gap: 12px;
        }
        
        .logo {
            width: 42px;
            height: 42px;
            background: var(--primary-gradient);
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 20px;
            box-shadow: 0 4px 12px rgba(99, 102, 241, 0.3);
        }
        
        .brand-text {
            font-size: 22px;
            font-weight: 700;
            color: var(--text);
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
            letter-spacing: -0.5px;
        }
        
        .nav-controls {
            display: flex;
            gap: 12px;
        }
        
        .nav-btn {
            width: 42px;
            height: 42px;
            border-radius: 50%;
            background: var(--primary-light);
            border: none;
            display: flex;
            align-items: center;
            justify-content: center;
            color: var(--primary);
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 16px;
            box-shadow: 0 4px 6px rgba(99, 102, 241, 0.1);
        }
        
        .nav-btn:hover {
            background: var(--primary);
            color: white;
            transform: translateY(-2px);
            box-shadow: 0 6px 15px rgba(99, 102, 241, 0.3);
        }
        
        /* 主内容区域 */
        .main-content {
            display: flex;
            flex: 1;
            overflow: hidden;
        }
        
        /* 侧边栏 - 玻璃拟态设计 */
        .sidebar {
            width: 280px;
            padding: 25px 20px;
            background: var(--glass-bg);
            border-right: 1px solid var(--glass-border);
            display: flex;
            flex-direction: column;
            transition: transform 0.3s ease;
            overflow-y: auto;
            backdrop-filter: blur(10px);
        }
        
        .ai-card {
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.05), rgba(139, 92, 246, 0.05));
            border-radius: var(--radius);
            padding: 20px;
            margin-bottom: 20px;
            border: 1px solid var(--glass-border);
            backdrop-filter: blur(5px);
        }
        
        .ai-card h3 {
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            color: var(--text);
        }
        
        .ai-card h3 i {
            color: var(--primary);
            font-size: 20px;
        }
        
        .ai-card p {
            font-size: 14px;
            line-height: 1.6;
            color: var(--text-light);
        }
        
        .info-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 12px;
            margin-bottom: 20px;
        }
        
        .info-card {
            background: rgba(224, 231, 255, 0.4);
            border-radius: 12px;
            padding: 15px;
            border: 1px solid var(--glass-border);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.02);
            backdrop-filter: blur(5px);
            transition: transform 0.3s ease;
        }
        
        .info-card:hover {
            transform: translateY(-3px);
        }
        
        .info-card .value {
            font-size: 20px;
            font-weight: 700;
            margin: 5px 0;
            color: var(--primary);
        }
        
        .info-card .label {
            font-size: 13px;
            color: var(--text-light);
        }
        
        .status-card {
            background: rgba(224, 231, 255, 0.4);
            border-radius: var(--radius);
            padding: 18px;
            border: 1px solid var(--glass-border);
            margin-top: auto;
            backdrop-filter: blur(5px);
        }
        
        .status-indicator {
            display: flex;
            align-items: center;
            margin-bottom: 15px;
            gap: 10px;
        }
        
        .indicator {
            width: 12px;
            height: 12px;
            background: var(--success);
            border-radius: 50%;
            box-shadow: 0 0 10px var(--success);
            animation: pulse 1.5s infinite;
        }
        
        @keyframes pulse {
            0% { opacity: 1; }
            50% { opacity: 0.5; }
            100% { opacity: 1; }
        }
        
        .status-text {
            font-weight: 600;
            color: var(--text);
        }
        
        .status-details {
            font-size: 14px;
            color: var(--text-light);
            line-height: 1.6;
        }
        
        /* 聊天区域 */
        .chat-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            background: var(--glass-bg);
            backdrop-filter: blur(5px);
        }
        
        .chat-header {
            padding: 16px 25px;
            background: var(--glass-bg);
            border-bottom: 1px solid var(--glass-border);
            display: flex;
            align-items: center;
            justify-content: space-between;
            backdrop-filter: blur(10px);
        }
        
        .chat-title {
            font-size: 18px;
            font-weight: 600;
            color: var(--text);
        }
        
        .chat-subtitle {
            font-size: 14px;
            color: var(--text-light);
            margin-top: 4px;
        }
        
        .new-chat-btn {
            background: var(--primary-gradient);
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
        }
        
        .new-chat-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, 0.4);
        }
        
        .chat-messages {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
            display: flex;
            flex-direction: column;
            background: transparent;
            -webkit-overflow-scrolling: touch;
            scroll-behavior: smooth;
        }
        
        .message {
            max-width: 75%;
            padding: 16px 20px;
            margin-bottom: 16px;
            border-radius: var(--radius);
            position: relative;
            line-height: 1.6;
            animation: fadeIn 0.4s cubic-bezier(0.22, 0.61, 0.36, 1);
            font-size: 16px;
            box-shadow: var(--shadow);
            word-break: break-word;
            transition: transform 0.3s ease;
            backdrop-filter: blur(5px);
        }
        
        .message:hover {
            transform: translateY(-2px);
        }
        
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(15px); }
            to { opacity: 1; transform: translateY(0); }
        }
        
        .ai-message {
            align-self: flex-start;
            background: var(--ai-bubble);
            border-radius: var(--radius) var(--radius) var(--radius) 8px;
            color: var(--text);
            border: 1px solid var(--glass-border);
        }
        
        .user-message {
            align-self: flex-end;
            background: var(--primary-gradient);
            color: white;
            border-radius: var(--radius) var(--radius) 8px var(--radius);
        }
        
        .message-time {
            font-size: 12px;
            margin-top: 10px;
            opacity: 0.7;
            display: flex;
            align-items: center;
            gap: 6px;
        }
        
        .ai-message .message-time {
            color: var(--text-light);
        }
        
        .user-message .message-time {
            color: rgba(255, 255, 255, 0.85);
            justify-content: flex-end;
        }
        
        /* 输入区域 */
        .input-container {
            padding: 20px;
            background: var(--glass-bg);
            border-top: 1px solid var(--glass-border);
            position: relative;
            backdrop-filter: blur(10px);
        }
        
        .input-box {
            display: flex;
            align-items: center;
            background: rgba(255, 255, 255, 0.9);
            border-radius: 50px;
            padding: 5px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--glass-border);
            transition: all 0.3s ease;
        }
        
        .input-box:focus-within {
            box-shadow: 0 5px 20px rgba(99, 102, 241, 0.2);
            border-color: var(--primary);
        }
        
        .message-input {
            flex: 1;
            padding: 14px 20px;
            border: none;
            border-radius: 50px;
            font-size: 16px;
            outline: none;
            background: transparent;
            min-height: 20px;
            resize: none;
            max-height: 150px;
            height: 24px;
            overflow-y: hidden;
        }
        
        .send-button {
            background: var(--primary-gradient);
            color: white;
            border: none;
            width: 48px;
            height: 48px;
            border-radius: 50%;
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            transition: all 0.3s ease;
            box-shadow: 0 5px 15px rgba(99, 102, 241, 0.3);
            flex-shrink: 0;
        }
        
        .send-button:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 8px 20px rgba(99, 102, 241, 0.4);
        }
        
        /* 加载动画 */
        .typing-indicator {
            display: flex;
            align-items: center;
            padding: 14px 20px;
            background: var(--ai-bubble);
            border-radius: var(--radius);
            align-self: flex-start;
            margin-bottom: 16px;
            box-shadow: var(--shadow);
            font-size: 15px;
            gap: 12px;
            animation: fadeIn 0.4s ease;
            backdrop-filter: blur(5px);
            border: 1px solid var(--glass-border);
        }
        
        .typing-dots {
            display: flex;
            gap: 4px;
        }
        
        .typing-dots span {
            height: 8px;
            width: 8px;
            border-radius: 50%;
            background: var(--primary);
            display: inline-block;
            animation: bounce 1.3s linear infinite;
        }
        
        .typing-dots span:nth-child(2) {
            animation-delay: 0.15s;
        }
        
        .typing-dots span:nth-child(3) {
            animation-delay: 0.3s;
        }
        
        @keyframes bounce {
            0%, 60%, 100% {
                transform: translateY(0);
            }
            30% {
                transform: translateY(-5px);
            }
        }
        
        /* 实名认证模块 */
        .verification-modal {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            display: flex;
            align-items: center;
            justify-content: center;
            z-index: 1000;
            backdrop-filter: blur(5px);
        }
        
        .verification-box {
            background: white;
            border-radius: 20px;
            width: 100%;
            max-width: 500px;
            padding: 30px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.2);
            position: relative;
        }
        
        .verification-header {
            text-align: center;
            margin-bottom: 25px;
        }
        
        .verification-header h2 {
            font-size: 24px;
            color: var(--text);
            margin-bottom: 10px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .verification-header p {
            color: var(--text-light);
            font-size: 15px;
        }
        
        .verification-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }
        
        .form-group label {
            font-weight: 500;
            color: var(--text);
            font-size: 15px;
        }
        
        .form-control {
            padding: 16px 18px;
            border: 1px solid var(--border);
            border-radius: 12px;
            font-size: 16px;
            transition: all 0.3s ease;
            background: rgba(255, 255, 255, 0.9);
        }
        
        .form-control:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
            outline: none;
        }
        
        .btn {
            padding: 16px 20px;
            border-radius: 12px;
            font-size: 16px;
            font-weight: 600;
            border: none;
            cursor: pointer;
            transition: all 0.3s ease;
            text-align: center;
        }
        
        .btn-primary {
            background: var(--primary-gradient);
            color: white;
            box-shadow: 0 4px 15px rgba(99, 102, 241, 0.3);
        }
        
        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 6px 20px rgba(99, 102, 241, 0.4);
        }
        
        .btn-block {
            display: block;
            width: 100%;
        }
        
        .verification-status {
            display: flex;
            align-items: center;
            gap: 15px;
            padding: 15px;
            background: rgba(16, 185, 129, 0.1);
            border-radius: 12px;
            margin-top: 20px;
            border: 1px solid rgba(16, 185, 129, 0.3);
        }
        
        .verification-status i {
            font-size: 24px;
            color: var(--success);
        }
        
        .verification-status h3 {
            font-size: 18px;
            color: var(--text);
        }
        
        .verification-status p {
            font-size: 14px;
            color: var(--text-light);
        }
        
        /* 用户中心样式 */
        .profile-card {
            background: rgba(255, 255, 255, 0.9);
            border-radius: 16px;
            padding: 25px;
            margin-bottom: 20px;
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--border);
        }
        
        .profile-header {
            display: flex;
            align-items: center;
            gap: 15px;
            margin-bottom: 20px;
        }
        
        .profile-avatar {
            width: 60px;
            height: 60px;
            border-radius: 50%;
            background: var(--primary-gradient);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
        }
        
        .profile-info h2 {
            font-size: 20px;
            color: var(--text);
            margin-bottom: 5px;
        }
        
        .profile-info p {
            color: var(--text-light);
            font-size: 14px;
        }
        
        .verification-badge {
            display: inline-flex;
            align-items: center;
            gap: 6px;
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
            margin-top: 8px;
        }
        
        .verified {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }
        
        .unverified {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 20px;
        }
        
        .stat-card {
            background: rgba(224, 231, 255, 0.4);
            border-radius: 12px;
            padding: 15px;
            border: 1px solid var(--glass-border);
            text-align: center;
        }
        
        .stat-card .number {
            font-size: 24px;
            font-weight: 700;
            color: var(--primary);
            margin-bottom: 5px;
        }
        
        .stat-card .label {
            font-size: 14px;
            color: var(--text-light);
        }
        
        .tab-container {
            display: flex;
            gap: 10px;
            margin-bottom: 20px;
        }
        
        .tab {
            padding: 12px 20px;
            border-radius: 12px;
            background: rgba(224, 231, 255, 0.4);
            border: 1px solid var(--glass-border);
            cursor: pointer;
            transition: all 0.3s ease;
            font-weight: 500;
        }
        
        .tab.active {
            background: var(--primary-gradient);
            color: white;
            border-color: var(--primary);
        }
        
        .tab-content {
            display: none;
        }
        
        .tab-content.active {
            display: block;
        }
        
        /* 滚动条样式 */
        .chat-messages::-webkit-scrollbar {
            width: 8px;
        }
        
        .chat-messages::-webkit-scrollbar-track {
            background: transparent;
            border-radius: 4px;
        }
        
        .chat-messages::-webkit-scrollbar-thumb {
            background: rgba(99, 102, 241, 0.3);
            border-radius: 4px;
        }
        
        .chat-messages::-webkit-scrollbar-thumb:hover {
            background: rgba(99, 102, 241, 0.5);
        }
        
        /* 响应式设计 */
        @media (max-width: 768px) {
            body {
                padding: 10px;
            }
            
            .container {
                height: 95vh;
                border-radius: 12px;
            }
            
            .sidebar {
                position: absolute;
                left: -100%;
                top: 0;
                height: 100%;
                z-index: 100;
                background: var(--card-bg);
                width: 85%;
                padding: 20px 15px;
                box-shadow: 5px 0 15px rgba(0, 0, 0, 0.1);
            }
            
            .sidebar.active {
                left: 0;
            }
            
            .chat-header {
                padding: 14px 18px;
            }
            
            .chat-messages {
                padding: 15px;
            }
            
            .message {
                max-width: 90%;
                padding: 14px 16px;
                margin-bottom: 14px;
                font-size: 15px;
            }
            
            .input-container {
                padding: 15px;
            }
            
            .message-input {
                padding: 12px 16px;
                font-size: 15px;
            }
            
            .send-button {
                width: 44px;
                height: 44px;
            }
        }
        
        /* 水波纹效果 */
        .ripple {
            position: absolute;
            border-radius: 50%;
            background: rgba(255, 255, 255, 0.4);
            transform: scale(0);
            animation: ripple 0.6s linear;
            pointer-events: none;
        }
        
        @keyframes ripple {
            to {
                transform: scale(4);
                opacity: 0;
            }
        }
        
        /* 移动端底部安全区域 */
        @supports (padding-bottom: env(safe-area-inset-bottom)) {
            .input-container {
                padding-bottom: calc(20px + env(safe-area-inset-bottom));
            }
        }
        
        .welcome-banner {
            text-align: center;
            padding: 30px 20px;
            max-width: 600px;
            margin: 0 auto;
        }
        
        .welcome-banner h2 {
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 15px;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .welcome-banner p {
            font-size: 16px;
            color: var(--text-light);
            line-height: 1.7;
            margin-bottom: 25px;
        }
        
        .features-grid {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 15px;
            margin-top: 25px;
        }
        
        .feature-card {
            background: rgba(224, 231, 255, 0.4);
            border-radius: 14px;
            padding: 18px;
            border: 1px solid var(--glass-border);
            text-align: center;
            transition: transform 0.3s ease;
            backdrop-filter: blur(5px);
        }
        
        .feature-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(99, 102, 241, 0.1);
        }
        
        .feature-icon {
            width: 48px;
            height: 48px;
            background: white;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            color: var(--primary);
            font-size: 20px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.05);
        }
        
        .feature-card h4 {
            font-size: 16px;
            margin-bottom: 8px;
            color: var(--text);
        }
        
        .feature-card p {
            font-size: 14px;
            color: var(--text-light);
        }
        
        .empty-state {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            text-align: center;
            padding: 40px 20px;
            color: var(--text-light);
        }
        
        .empty-state i {
            font-size: 48px;
            color: var(--primary);
            margin-bottom: 20px;
        }
        
        .empty-state h3 {
            font-size: 22px;
            margin-bottom: 10px;
            color: var(--text);
        }
        
        /* 现代化登录表单 */
        .auth-container {
            display: flex;
            flex-direction: column;
            width: 100%;
            max-width: 450px;
            background: var(--glass-bg);
            border-radius: 20px;
            box-shadow: var(--glass-shadow);
            overflow: hidden;
            margin: 0 auto;
            backdrop-filter: blur(10px);
            border: 1px solid var(--glass-border);
        }
        
        .auth-header {
            background: var(--primary-gradient);
            padding: 35px 30px;
            text-align: center;
            color: white;
        }
        
        .auth-header h2 {
            font-size: 28px;
            margin-bottom: 10px;
            font-weight: 700;
        }
        
        .auth-header p {
            font-size: 16px;
            opacity: 0.9;
            font-weight: 300;
        }
        
        .auth-body {
            padding: 30px;
        }
        
        .auth-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }
        
        .auth-footer {
            display: flex;
            justify-content: space-between;
            margin-top: 10px;
        }
        
        .auth-footer a {
            color: var(--primary);
            text-decoration: none;
            font-size: 14px;
            font-weight: 500;
            transition: all 0.3s ease;
        }
        
        .auth-footer a:hover {
            text-decoration: underline;
            color: var(--primary-dark);
        }
        
        .btn-outline {
            background: transparent;
            border: 1px solid var(--glass-border);
            color: var(--text);
            transition: all 0.3s ease;
        }
        
        .btn-outline:hover {
            background: rgba(255, 255, 255, 0.2);
            border-color: var(--primary);
            color: var(--primary);
        }
        
        .divider {
            display: flex;
            align-items: center;
            text-align: center;
            color: var(--text-light);
            margin: 15px 0;
            font-size: 14px;
        }
        
        .divider::before,
        .divider::after {
            content: '';
            flex: 1;
            border-bottom: 1px solid var(--glass-border);
        }
        
        .divider::before {
            margin-right: 10px;
        }
        
        .divider::after {
            margin-left: 10px;
        }
        
        .token-counter {
            position: absolute;
            top: 20px;
            right: 20px;
            background: rgba(255, 255, 255, 0.9);
            padding: 8px 18px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 600;
            color: var(--primary);
            display: flex;
            align-items: center;
            gap: 8px;
            z-index: 100;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.05);
            border: 1px solid var(--glass-border);
        }
        
        .token-counter i {
            font-size: 16px;
        }
        
        .alert {
            padding: 14px 18px;
            border-radius: 12px;
            margin-bottom: 20px;
            font-size: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
            backdrop-filter: blur(5px);
        }
        
        .alert-warning {
            background: rgba(245, 158, 11, 0.1);
            border: 1px solid rgba(245, 158, 11, 0.3);
            color: #c05621;
        }
        
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: #047857;
        }
        
        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #b91c1c;
        }
        
        .alert-info {
            background: rgba(99, 102, 241, 0.1);
            border: 1px solid rgba(99, 102, 241, 0.3);
            color: var(--primary-dark);
        }
        
        .floating-bg {
            position: absolute;
            width: 200px;
            height: 200px;
            border-radius: 50%;
            background: linear-gradient(135deg, rgba(99, 102, 241, 0.1), rgba(236, 72, 153, 0.1));
            filter: blur(60px);
            z-index: -1;
        }
        
        .bg-1 {
            top: 10%;
            left: 10%;
            width: 300px;
            height: 300px;
        }
        
        .bg-2 {
            bottom: 10%;
            right: 10%;
            width: 250px;
            height: 250px;
        }
        
        .id-card-example {
            font-size: 13px;
            color: var(--text-light);
            margin-top: 5px;
            padding: 10px;
            background: rgba(0, 0, 0, 0.03);
            border-radius: 8px;
        }
    </style>
</head>
<body>
    <div class="floating-bg bg-1"></div>
    <div class="floating-bg bg-2"></div>
    
    <?php if (!isUserLoggedIn()): ?>
    <!-- 登录/注册表单 -->
    <div class="auth-container">
        <div class="auth-header">
            <h2>DeepSeek AI 客服系统</h2>
            <p>登录后体验智能AI客服服务</p>
        </div>
        <div class="auth-body">
            <div id="loginForm" class="auth-form">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> 新用户请先注册，注册后获得<?= DEFAULT_TOKENS ?> tokens免费额度
                </div>
                <div class="form-group">
                    <label for="username">用户名</label>
                    <input type="text" id="username" class="form-control" placeholder="请输入用户名">
                </div>
                <div class="form-group">
                    <label for="password">密码</label>
                    <input type="password" id="password" class="form-control" placeholder="请输入密码">
                </div>
                <button id="loginBtn" class="btn btn-primary">登录</button>
                <div class="divider">或</div>
                <button id="showRegisterBtn" class="btn btn-outline">注册新账号</button>
            </div>
            
            <div id="registerForm" class="auth-form" style="display: none;">
                <div class="alert alert-info">
                    <i class="fas fa-info-circle"></i> 注册后即可开始使用AI客服服务
                </div>
                <div class="form-group">
                    <label for="regUsername">用户名</label>
                    <input type="text" id="regUsername" class="form-control" placeholder="设置您的用户名">
                </div>
                <div class="form-group">
                    <label for="regPassword">密码</label>
                    <input type="password" id="regPassword" class="form-control" placeholder="设置密码（至少6位）">
                </div>
                <div class="form-group">
                    <label for="confirmPassword">确认密码</label>
                    <input type="password" id="confirmPassword" class="form-control" placeholder="再次输入密码">
                </div>
                <button id="registerBtn" class="btn btn-primary">注册</button>
                <div class="divider">或</div>
                <button id="showLoginBtn" class="btn btn-outline">返回登录</button>
            </div>
            
            <div id="authMessage" class="alert" style="display: none; margin-top: 20px;"></div>
        </div>
    </div>
    <?php else: ?>
    <!-- 主应用界面 -->
    <div class="container">
        
        <div class="navbar">
            <div class="brand">
                <div class="logo">
                    <i class="fas fa-robot"></i>
                </div>
                <div class="brand-text">DeepSeek AI</div>
            </div>
            <div class="nav-controls">
                <button class="nav-btn" id="menuBtn">
                    <i class="fas fa-bars"></i>
                </button>
                <a href="?new" class="nav-btn" title="新对话">
                    <i class="fas fa-plus"></i>
                </a>
                <a href="?logout" class="nav-btn" title="退出登录">
                    <i class="fas fa-sign-out-alt"></i>
                </a>
            </div>
        </div>
        
        <div class="main-content">
            <!-- 侧边栏 -->
            <div class="sidebar" id="sidebar">
                <div class="profile-card">
                    <div class="profile-header">
                        <div class="profile-avatar">
                            <?php echo strtoupper(substr($_SESSION['username'], 0, 1)); ?>
                        </div>
                        <div class="profile-info">
                            <h2><?= $_SESSION['username'] ?></h2>
                            <?php if ($_SESSION['real_name_verified']): ?>
                                <span class="verification-badge verified">
                                    <i class="fas fa-check-circle"></i> 已实名认证
                                </span>
                            <?php else: ?>
                                <span class="verification-badge unverified">
                                    <i class="fas fa-exclamation-circle"></i> 未实名认证
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="stats-grid">
                        <div class="stat-card">
                            <div class="number"><?= $_SESSION['tokens'] ?></div>
                            <div class="label">剩余tokens</div>
                        </div>

                    </div>
                </div>
                
                <div class="ai-card">
                    <h3><i class="fas fa-info-circle"></i> 实名认证说明</h3>
                    <p>根据国家法规要求，使用AI服务需要进行实名认证。认证后您将获得完整的AI对话权限。</p>
                    <?php if (!$_SESSION['real_name_verified']): ?>
                        <button class="btn btn-primary" id="verifyBtn" style="margin-top: 15px; width: 100%;">
                            <i class="fas fa-id-card"></i> 立即实名认证
                        </button>
                    <?php endif; ?>
                </div>
                
                <div class="ai-card">
                    <h3><i class="fas fa-lightbulb"></i> 使用技巧</h3>
                    <p>• 清晰地描述您的问题<br>
                       • 我可以处理多种类型的问题<br>
                       • 回答可能需要几秒钟时间<br>
                       • 使用"新对话"可清除历史记录</p>
                </div>
                
                <div class="status-card">
                    <div class="status-indicator">
                        <div class="indicator"></div>
                        <div class="status-text">服务在线</div>
                    </div>
                    <div class="status-details">
                        DeepSeek API 运行正常<br>
                        最后检测: <?php echo date('H:i'); ?>
                    </div>
                </div>
            </div>
            
            <!-- 聊天区域 -->
            <div class="chat-container">
                <div class="chat-header">
                    <div>
                        <div class="chat-title">AI智能客服</div>
                        <div class="chat-subtitle">随时为您提供专业帮助</div>
                    </div>
                    <a href="?new" class="new-chat-btn">
                        <i class="fas fa-plus"></i> 新对话
                    </a>
                </div>
                
                <div class="chat-messages" id="chatMessages">
                    <!-- 欢迎横幅 -->
                    <div class="welcome-banner">
                        <h2>欢迎使用DeepSeek AI助手</h2>
                        <p>我是您的智能客服，可以解答各种问题、提供建议和技术支持。请随时向我提问！</p>
                        
                        <div class="features-grid">
                            <div class="feature-card">
                                <div class="feature-icon">
                                    <i class="fas fa-bolt"></i>
                                </div>
                                <h4>快速响应</h4>
                                <p>平均响应时间小于1秒</p>
                            </div>
                            <div class="feature-card">
                                <div class="feature-icon">
                                    <i class="fas fa-brain"></i>
                                </div>
                                <h4>智能理解</h4>
                                <p>理解自然语言问题</p>
                            </div>
                            <div class="feature-card">
                                <div class="feature-icon">
                                    <i class="fas fa-shield-alt"></i>
                                </div>
                                <h4>安全可靠</h4>
                                <p>端到端数据加密</p>
                            </div>
                            <div class="feature-card">
                                <div class="feature-icon">
                                    <i class="fas fa-infinity"></i>
                                </div>
                                <h4>24小时服务</h4>
                                <p>全天候为您提供支持</p>
                            </div>
                        </div>
                    </div>
                    
                    <!-- AI欢迎消息 -->
                    <div class="message ai-message">
                        <?php if ($_SESSION['real_name_verified']): ?>
                            <div>您好！<?= $_SESSION['username'] ?>，我是DeepSeek智能客服助手，很高兴为您服务。您当前有 <strong><?= $_SESSION['tokens'] ?> tokens</strong> 可用额度。</div>
                        <?php else: ?>
                            <div>欢迎回来！<?= $_SESSION['username'] ?>。根据国家法规要求，使用AI服务需要进行实名认证。请完成实名认证后开始使用AI服务。</div>
                        <?php endif; ?>
                        <div class="message-time">
                            <i class="far fa-clock"></i> <?php echo date('H:i'); ?>
                        </div>
                    </div>
                    
                    <?php
                    // 显示历史消息
                    if (isset($_SESSION['chat_history'])) {
                        foreach ($_SESSION['chat_history'] as $message) {
                            if ($message['role'] === 'user') {
                                echo '<div class="message user-message">';
                                echo '<div>'.htmlspecialchars($message['content']).'</div>';
                                echo '<div class="message-time"><i class="far fa-clock"></i> '.date('H:i').'</div>';
                                echo '</div>';
                            } elseif ($message['role'] === 'assistant') {
                                echo '<div class="message ai-message">';
                                echo '<div>'.nl2br(htmlspecialchars($message['content'])).'</div>';
                                echo '<div class="message-time"><i class="far fa-clock"></i> '.date('H:i').'</div>';
                                echo '</div>';
                            }
                        }
                    }
                    ?>
                    
                    <!-- 正在输入指示器 -->
                    <div class="typing-indicator" id="typingIndicator" style="display: none;">
                        <div class="typing-dots">
                            <span></span>
                            <span></span>
                            <span></span>
                        </div>
                        <div>AI正在思考中...</div>
                    </div>
                </div>
                
                <!-- 输入区域 -->
                <div class="input-container">
                    <div class="input-box">
                        <textarea class="message-input" id="messageInput" placeholder="输入您的问题..." rows="1" autocomplete="off" <?php echo !$_SESSION['real_name_verified'] ? 'disabled' : ''; ?>></textarea>
                        <button class="send-button" id="sendButton" <?php echo !$_SESSION['real_name_verified'] ? 'disabled' : ''; ?>>
                            <i class="fas fa-paper-plane"></i>
                        </button>
                    </div>
                    <?php if (!$_SESSION['real_name_verified']): ?>
                        <div class="alert alert-warning" style="margin-top: 15px;">
                            <i class="fas fa-exclamation-triangle"></i> 请先完成实名认证才能使用AI服务
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
    
    <!-- 实名认证模态框 -->
    <?php if (!$_SESSION['real_name_verified']): ?>
        <div class="verification-modal" id="verificationModal">
            <div class="verification-box">
                <div class="verification-header">
                    <h2>实名认证</h2>
                    <p>根据国家法规要求，使用AI服务需要进行实名认证</p>
                </div>
                
                <div class="verification-form">
                    <div class="form-group">
                        <label for="realName">真实姓名</label>
                        <input type="text" id="realName" class="form-control" placeholder="请输入您的真实姓名">
                    </div>
                    
                    <div class="form-group">
                        <label for="idCard">身份证号码</label>
                        <input type="text" id="idCard" class="form-control" placeholder="请输入您的身份证号码">
                        <div class="id-card-example">示例: 11010119900307999X</div>
                    </div>
                    
                    <div class="alert alert-info">
                        <i class="fas fa-info-circle"></i> 您的个人信息将严格保密，仅用于实名认证
                    </div>
                    
                    <button class="btn btn-primary btn-block" id="submitVerification">
                        <i class="fas fa-check"></i> 提交认证
                    </button>
                    
                    <div id="verificationMessage" class="alert" style="display: none; margin-top: 15px;"></div>
                </div>
            </div>
        </div>
    <?php endif; ?>
    <?php endif; ?>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            <?php if (isUserLoggedIn()): ?>
            // 登录后的功能
            const chatMessages = document.getElementById('chatMessages');
            const messageInput = document.getElementById('messageInput');
            const sendButton = document.getElementById('sendButton');
            const typingIndicator = document.getElementById('typingIndicator');
            const menuBtn = document.getElementById('menuBtn');
            const sidebar = document.getElementById('sidebar');
            const tokenCounter = document.getElementById('tokenCounter');
            const tokenValue = document.getElementById('tokenValue');
            
            // 实名认证元素
            const verificationModal = document.getElementById('verificationModal');
            const verifyBtn = document.getElementById('verifyBtn');
            const submitVerification = document.getElementById('submitVerification');
            const verificationMessage = document.getElementById('verificationMessage');
            
            // 自动调整输入框高度
            function autoResize() {
                messageInput.style.height = 'auto';
                messageInput.style.height = (messageInput.scrollHeight) + 'px';
            }
            
            messageInput.addEventListener('input', autoResize);
            
            // 滚动到最新消息
            function scrollToBottom() {
                chatMessages.scrollTop = chatMessages.scrollHeight;
            }
            
            scrollToBottom();
            
            // 发送消息函数
            function sendMessage() {
                const message = messageInput.value.trim();
                if (message === '') return;
                
                // 添加用户消息
                const now = new Date();
                const timeString = `${now.getHours().toString().padStart(2, '0')}:${now.getMinutes().toString().padStart(2, '0')}`;
                
                const userMessageDiv = document.createElement('div');
                userMessageDiv.className = 'message user-message';
                userMessageDiv.innerHTML = `
                    <div>${message}</div>
                    <div class="message-time"><i class="far fa-clock"></i> ${timeString}</div>
                `;
                
                chatMessages.appendChild(userMessageDiv);
                messageInput.value = '';
                autoResize(); // 重置高度
                
                // 显示正在输入指示器
                typingIndicator.style.display = 'flex';
                scrollToBottom();
                
                // 发送AJAX请求到服务器
                fetch('<?php echo $_SERVER['PHP_SELF']; ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `message=${encodeURIComponent(message)}`
                })
                .then(response => response.json())
                .then(data => {
                    typingIndicator.style.display = 'none';
                    
                    if (data.error) {
                        const errorDiv = document.createElement('div');
                        errorDiv.className = 'message ai-message alert-error';
                        errorDiv.innerHTML = `
                            <div><i class="fas fa-exclamation-circle"></i> ${data.error}</div>
                            <div class="message-time"><i class="far fa-clock"></i> ${timeString}</div>
                        `;
                        chatMessages.appendChild(errorDiv);
                    } else if (data.ai_response) {
                        const aiMessageDiv = document.createElement('div');
                        aiMessageDiv.className = 'message ai-message';
                        aiMessageDiv.innerHTML = `
                            <div>${data.ai_response.replace(/\n/g, '<br>')}</div>
                            <div class="message-time"><i class="far fa-clock"></i> ${data.timestamp}</div>
                        `;
                        
                        chatMessages.appendChild(aiMessageDiv);
                        
                        // 显示token警告（如果有）
                        if (data.token_warning) {
                            const warningDiv = document.createElement('div');
                            warningDiv.className = 'message ai-message alert-warning';
                            warningDiv.innerHTML = `
                                <div><i class="fas fa-exclamation-triangle"></i> ${data.token_warning}</div>
                                <div class="message-time"><i class="far fa-clock"></i> ${data.timestamp}</div>
                            `;
                            chatMessages.appendChild(warningDiv);
                        }
                        
                        // 更新token计数器
                        tokenValue.textContent = `${data.remaining_tokens} tokens`;
                        
                        scrollToBottom();
                    }
                })
                .catch(error => {
                    typingIndicator.style.display = 'none';
                    console.error('Error:', error);
                    
                    const errorDiv = document.createElement('div');
                    errorDiv.className = 'message ai-message alert-error';
                    errorDiv.innerHTML = `
                        <div><i class="fas fa-exclamation-circle"></i> 抱歉，处理您的请求时出错。请稍后再试。</div>
                        <div class="message-time"><i class="far fa-clock"></i> ${timeString}</div>
                    `;
                    
                    chatMessages.appendChild(errorDiv);
                    scrollToBottom();
                });
            }
            
            // 事件监听
            sendButton.addEventListener('click', sendMessage);
            
            messageInput.addEventListener('keypress', function(e) {
                if (e.key === 'Enter' && !e.shiftKey) {
                    e.preventDefault();
                    sendMessage();
                }
            });
            
            // 输入框自动聚焦
            messageInput.focus();
            
            // 菜单按钮点击事件
            menuBtn.addEventListener('click', function() {
                sidebar.classList.toggle('active');
            });
            
            // 实名认证功能
            if (verifyBtn) {
                verifyBtn.addEventListener('click', function() {
                    verificationModal.style.display = 'flex';
                });
            }
            
            if (submitVerification) {
                submitVerification.addEventListener('click', function() {
                    const realName = document.getElementById('realName').value.trim();
                    const idCard = document.getElementById('idCard').value.trim();
                    
                    if (!realName || !idCard) {
                        showVerificationMessage('请填写所有字段', 'error');
                        return;
                    }
                    
                    fetch('<?php echo $_SERVER['PHP_SELF']; ?>', {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/x-www-form-urlencoded',
                        },
                        body: `action=verify_real_name&real_name=${encodeURIComponent(realName)}&id_card=${encodeURIComponent(idCard)}`
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.error) {
                            showVerificationMessage(data.error, 'error');
                        } else if (data.success) {
                            showVerificationMessage('实名认证成功！页面即将刷新...', 'success');
                            setTimeout(() => {
                                location.reload();
                            }, 2000);
                        }
                    })
                    .catch(error => {
                        console.error('Error:', error);
                        showVerificationMessage('网络请求失败，请重试', 'error');
                    });
                });
            }
            
            function showVerificationMessage(message, type) {
                verificationMessage.textContent = message;
                verificationMessage.className = `alert alert-${type}`;
                verificationMessage.style.display = 'flex';
            }
            
            // 点击模态框外部关闭
            if (verificationModal) {
                verificationModal.addEventListener('click', function(e) {
                    if (e.target === verificationModal) {
                        verificationModal.style.display = 'none';
                    }
                });
            }
            <?php else: ?>
            // 登录/注册功能
            const authContainer = document.getElementById('authContainer');
            const loginForm = document.getElementById('loginForm');
            const registerForm = document.getElementById('registerForm');
            const showRegisterBtn = document.getElementById('showRegisterBtn');
            const showLoginBtn = document.getElementById('showLoginBtn');
            const loginBtn = document.getElementById('loginBtn');
            const registerBtn = document.getElementById('registerBtn');
            const authMessage = document.getElementById('authMessage');
            
            // 切换登录/注册表单
            showRegisterBtn.addEventListener('click', () => {
                loginForm.style.display = 'none';
                registerForm.style.display = 'flex';
                authMessage.style.display = 'none';
            });
            
            showLoginBtn.addEventListener('click', () => {
                registerForm.style.display = 'none';
                loginForm.style.display = 'flex';
                authMessage.style.display = 'none';
            });
            
            // 处理登录
            loginBtn.addEventListener('click', () => {
                const username = document.getElementById('username').value.trim();
                const password = document.getElementById('password').value;
                
                if (!username || !password) {
                    showAuthMessage('请输入用户名和密码', 'error');
                    return;
                }
                
                fetch('<?php echo $_SERVER['PHP_SELF']; ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=login&username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        showAuthMessage(data.error, 'error');
                    } else if (data.success) {
                        location.reload();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAuthMessage('网络请求失败，请重试', 'error');
                });
            });
            
            // 处理注册
            registerBtn.addEventListener('click', () => {
                const username = document.getElementById('regUsername').value.trim();
                const password = document.getElementById('regPassword').value;
                const confirmPassword = document.getElementById('confirmPassword').value;
                
                if (!username || !password || !confirmPassword) {
                    showAuthMessage('请填写所有字段', 'error');
                    return;
                }
                
                if (password.length < 6) {
                    showAuthMessage('密码长度至少为6位', 'error');
                    return;
                }
                
                if (password !== confirmPassword) {
                    showAuthMessage('两次输入的密码不一致', 'error');
                    return;
                }
                
                fetch('<?php echo $_SERVER['PHP_SELF']; ?>', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: `action=register&username=${encodeURIComponent(username)}&password=${encodeURIComponent(password)}`
                })
                .then(response => response.json())
                .then(data => {
                    if (data.error) {
                        showAuthMessage(data.error, 'error');
                    } else if (data.success) {
                        location.reload();
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                    showAuthMessage('注册失败，请重试', 'error');
                });
            });
            
            // 显示认证消息
            function showAuthMessage(message, type) {
                authMessage.textContent = message;
                authMessage.className = `alert alert-${type}`;
                authMessage.style.display = 'flex';
            }
            <?php endif; ?>
        });
    </script>
</body>
</html>