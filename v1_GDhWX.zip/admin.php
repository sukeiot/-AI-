<div class="web_notice" style="
position: fixed;
top: 0;
left: 0;
width: 100%;
height: 100%;
background: rgba(0,0,0,0.3);
z-index: 99999;
">
    <div style="position: fixed;top: 50%;left: 50%;width: 550px;background: #FFF;transform: translate(-50%, -50%);border-radius: 40px;padding: 50px 40px;">
        <h3 style="font-weight: bold;text-align: center;font-size: 30px;">网站通知
            <div style="
		font-size: 16px;
		margin-top: 26px;
		line-height: 30px;
		color: #999;">你好！欢迎登录速科物联AI系统后台！</div>
            <a style="
		display: block;
		background: #98a3ff;
		color: #FFF;
		text-align: center;
		font-weight: bold;
		font-size: 19px;
		line-height: 60px;
		margin: 0 auto;
		margin-top: 45px;
		border-radius: 32px;
		width: 80%;
		" onclick="javascript:document.querySelector('.web_notice').remove()">
                我知道了</a>
    </div>
</div>

<?php
session_start();

// 数据库配置
define('DB_HOST', 'localhost');
define('DB_USER', 'ai1');
define('DB_PASS', 'ai1');
define('DB_NAME', 'ai1');

// 创建数据库连接
$conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($conn->connect_error) {
    die("数据库连接失败: " . $conn->connect_error);
}

// 检查管理员表是否存在，不存在则创建
$checkTable = "CREATE TABLE IF NOT EXISTS admins (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($checkTable);

// 检查是否有管理员账号，没有则创建默认账号
$checkAdmin = $conn->query("SELECT * FROM admins");
if ($checkAdmin->num_rows == 0) {
    $defaultPass = password_hash('Admin@123', PASSWORD_DEFAULT);
    $conn->query("INSERT INTO admins (username, password) VALUES ('admin', '$defaultPass')");
}

// 管理员登录验证
$login_error = '';
if (isset($_POST['login'])) {
    $username = $conn->real_escape_string($_POST['username']);
    $password = $_POST['password'];
    
    $sql = "SELECT * FROM admins WHERE username = '$username'";
    $result = $conn->query($sql);
    
    if ($result->num_rows === 1) {
        $admin = $result->fetch_assoc();
        if (password_verify($password, $admin['password'])) {
            $_SESSION['admin_logged_in'] = true;
            $_SESSION['admin_username'] = $admin['username'];
            header('Location: admin.php');
            exit;
        }
    }
    
    $login_error = "用户名或密码错误";
}

// 管理员登出
if (isset($_GET['logout'])) {
    session_destroy();
    header('Location: admin.php');
    exit;
}

// 检查管理员登录状态
function isAdminLoggedIn() {
    return isset($_SESSION['admin_logged_in']) && $_SESSION['admin_logged_in'] === true;
}

// 如果用户已登录，则加载后台管理内容
if (isAdminLoggedIn()) {
    // 获取所有用户
    function getAllUsers($conn) {
        $sql = "SELECT users.*, real_name_verification.real_name, real_name_verification.id_card 
                FROM users 
                LEFT JOIN real_name_verification ON users.id = real_name_verification.user_id";
        $result = $conn->query($sql);
        $users = [];
        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                $users[] = $row;
            }
        }
        return $users;
    }

    // 添加新用户
    if (isset($_POST['add_user'])) {
        $username = $conn->real_escape_string($_POST['username']);
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT);
        $tokens = intval($_POST['tokens']);
        $real_name_verified = isset($_POST['real_name_verified']) ? 1 : 0;
        
        // 插入用户
        $sql = "INSERT INTO users (username, password, tokens, real_name_verified) 
                VALUES ('$username', '$password', $tokens, $real_name_verified)";
        
        if ($conn->query($sql)) {
            $user_id = $conn->insert_id;
            
            // 如果标记为已实名，插入实名信息
            if ($real_name_verified) {
                $real_name = $conn->real_escape_string($_POST['real_name']);
                $id_card = $conn->real_escape_string($_POST['id_card']);
                $sql = "INSERT INTO real_name_verification (user_id, real_name, id_card) 
                        VALUES ($user_id, '$real_name', '$id_card')";
                $conn->query($sql);
            }
            
            $success_message = "用户添加成功";
        } else {
            $error_message = "添加用户失败: " . $conn->error;
        }
    }

    // 更新用户信息
    if (isset($_POST['update_user'])) {
        $user_id = intval($_POST['user_id']);
        $username = $conn->real_escape_string($_POST['username']);
        $tokens = intval($_POST['tokens']);
        $real_name_verified = isset($_POST['real_name_verified']) ? 1 : 0;
        
        // 更新用户
        $sql = "UPDATE users SET 
                username = '$username', 
                tokens = $tokens, 
                real_name_verified = $real_name_verified 
                WHERE id = $user_id";
        
        if ($conn->query($sql)) {
            // 更新实名信息
            $real_name = $conn->real_escape_string($_POST['real_name']);
            $id_card = $conn->real_escape_string($_POST['id_card']);
            
            // 检查是否已有实名记录
            $check_sql = "SELECT * FROM real_name_verification WHERE user_id = $user_id";
            $result = $conn->query($check_sql);
            
            if ($real_name_verified) {
                if ($result->num_rows > 0) {
                    // 更新现有记录
                    $sql = "UPDATE real_name_verification SET 
                            real_name = '$real_name', 
                            id_card = '$id_card' 
                            WHERE user_id = $user_id";
                } else {
                    // 插入新记录
                    $sql = "INSERT INTO real_name_verification (user_id, real_name, id_card) 
                            VALUES ($user_id, '$real_name', '$id_card')";
                }
            } else {
                // 删除实名记录
                $sql = "DELETE FROM real_name_verification WHERE user_id = $user_id";
            }
            
            $conn->query($sql);
            $success_message = "用户信息更新成功";
        } else {
            $error_message = "更新用户失败: " . $conn->error;
        }
    }

    // 删除用户
    if (isset($_GET['delete_user'])) {
        $user_id = intval($_GET['delete_user']);
        
        // 先删除实名记录
        $sql = "DELETE FROM real_name_verification WHERE user_id = $user_id";
        $conn->query($sql);
        
        // 再删除用户
        $sql = "DELETE FROM users WHERE id = $user_id";
        if ($conn->query($sql)) {
            $success_message = "用户删除成功";
        } else {
            $error_message = "删除用户失败: " . $conn->error;
        }
    }

    // 获取用户详情
    if (isset($_GET['edit_user'])) {
        $user_id = intval($_GET['edit_user']);
        $sql = "SELECT users.*, real_name_verification.real_name, real_name_verification.id_card 
                FROM users 
                LEFT JOIN real_name_verification ON users.id = real_name_verification.user_id
                WHERE users.id = $user_id";
        $result = $conn->query($sql);
        $edit_user = $result->fetch_assoc();
    }

    // 获取所有用户
    $users = getAllUsers($conn);
}
?>
<!DOCTYPE html>
<html lang="zh-CN">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>DeepSeek AI - 后台管理系统</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', system-ui, -apple-system, sans-serif;
        }
        
        :root {
            --primary: #6366f1;
            --primary-dark: #4f46e5;
            --secondary: #ec4899;
            --text: #1e293b;
            --text-light: #64748b;
            --bg: #f8fafc;
            --sidebar-bg: #1e293b;
            --card-bg: #ffffff;
            --border: #e2e8f0;
            --success: #10b981;
            --error: #ef4444;
            --warning: #f59e0b;
            --radius: 8px;
            --shadow: 0 4px 6px rgba(0, 0, 0, 0.05);
        }
        
        /* 登录页面样式 */
        .login-container {
            display: flex;
            justify-content: center;
            align-items: center;
            width: 100%;
            height: 100vh;
            background: linear-gradient(to right, #fbc2eb, #a6c1ee);
        }
        
        .login-wrapper {
            background-color: #fff;
            width: 358px;
            height: 588px;
            border-radius: 15px;
            padding: 0 50px;
            position: relative;
            display: flex;
            flex-direction: column;
            justify-content: center;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.15);
        }
        
        .login-header {
            font-size: 38px;
            font-weight: bold;
            text-align: center;
            margin-bottom: 60px;
            color: #333;
            position: relative;
        }
        
        .login-header::after {
            content: '';
            position: absolute;
            bottom: -15px;
            left: 50%;
            transform: translateX(-50%);
            width: 60px;
            height: 4px;
            background: linear-gradient(to right, #a6c1ee, #fbc2eb);
            border-radius: 2px;
        }
        
        .input-item {
            display: block;
            width: 100%;
            margin-bottom: 30px;
            border: 0;
            padding: 15px 10px;
            border-bottom: 1px solid #aaa;
            font-size: 16px;
            outline: none;
            transition: all 0.3s ease;
        }
        
        .input-item:focus {
            border-bottom: 2px solid #a6c1ee;
        }
        
        .input-item::placeholder {
            color: #aaa;
        }
        
        .login-btn {
            text-align: center;
            padding: 14px;
            width: 100%;
            margin-top: 20px;
            background: linear-gradient(to right, #a6c1ee, #fbc2eb);
            color: #fff;
            border: none;
            border-radius: 30px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 4px 15px rgba(166, 193, 238, 0.4);
        }
        
        .login-btn:hover {
            transform: translateY(-3px);
            box-shadow: 0 6px 20px rgba(166, 193, 238, 0.6);
        }
        
        .msg {
            text-align: center;
            margin-top: 30px;
            color: #666;
            font-size: 14px;
        }
        
        .msg a {
            text-decoration: none;
            color: #a6c1ee;
            font-weight: 600;
            transition: all 0.3s ease;
        }
        
        .msg a:hover {
            color: #fbc2eb;
            text-decoration: underline;
        }
        
        .error-msg {
            color: #ef4444;
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
            min-height: 20px;
        }
        
        /* 后台管理样式 */
        body.admin-logged-in {
            background-color: #f1f5f9;
            color: var(--text);
            display: flex;
            min-height: 100vh;
        }
        
        .sidebar {
            width: 250px;
            background: var(--sidebar-bg);
            color: white;
            height: 100vh;
            position: fixed;
            padding: 20px 0;
            box-shadow: 0 0 15px rgba(0, 0, 0, 0.1);
        }
        
        .logo {
            text-align: center;
            padding: 20px 0;
            margin-bottom: 30px;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }
        
        .logo h2 {
            font-size: 24px;
            font-weight: 700;
            background: linear-gradient(90deg, var(--primary), var(--secondary));
            -webkit-background-clip: text;
            background-clip: text;
            color: transparent;
        }
        
        .nav-links {
            list-style: none;
            padding: 0 20px;
        }
        
        .nav-links li {
            margin-bottom: 5px;
        }
        
        .nav-links a {
            display: flex;
            align-items: center;
            padding: 12px 15px;
            color: rgba(255, 255, 255, 0.8);
            text-decoration: none;
            border-radius: var(--radius);
            transition: all 0.3s ease;
        }
        
        .nav-links a i {
            margin-right: 12px;
            width: 24px;
            text-align: center;
        }
        
        .nav-links a:hover, .nav-links a.active {
            background: rgba(99, 102, 241, 0.2);
            color: white;
        }
        
        .main-content {
            flex: 1;
            margin-left: 250px;
            padding: 30px;
        }
        
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            padding-bottom: 20px;
            border-bottom: 1px solid var(--border);
        }
        
        .header h1 {
            font-size: 28px;
            font-weight: 700;
            color: var(--text);
        }
        
        .user-info {
            display: flex;
            align-items: center;
        }
        
        .user-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }
        
        .user-info span {
            margin-right: 15px;
            font-weight: 500;
        }
        
        .btn {
            padding: 10px 20px;
            border-radius: var(--radius);
            font-weight: 500;
            cursor: pointer;
            border: none;
            transition: all 0.3s ease;
            display: inline-flex;
            align-items: center;
            gap: 8px;
        }
        
        .btn-primary {
            background: var(--primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--primary-dark);
        }
        
        .btn-danger {
            background: var(--error);
            color: white;
        }
        
        .btn-danger:hover {
            background: #dc2626;
        }
        
        .btn-outline {
            background: transparent;
            border: 1px solid var(--primary);
            color: var(--primary);
        }
        
        .btn-outline:hover {
            background: rgba(99, 102, 241, 0.1);
        }
        
        .card {
            background: var(--card-bg);
            border-radius: var(--radius);
            box-shadow: var(--shadow);
            margin-bottom: 30px;
            border: 1px solid var(--border);
        }
        
        .card-header {
            padding: 20px;
            border-bottom: 1px solid var(--border);
            display: flex;
            justify-content: space-between;
            align-items: center;
        }
        
        .card-header h2 {
            font-size: 20px;
            font-weight: 600;
        }
        
        .card-body {
            padding: 20px;
        }
        
        .table-container {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 15px;
            text-align: left;
            border-bottom: 1px solid var(--border);
        }
        
        th {
            background-color: #f8fafc;
            font-weight: 600;
            color: var(--text-light);
        }
        
        tr:hover {
            background-color: #f8fafc;
        }
        
        .status-badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 13px;
            font-weight: 500;
        }
        
        .status-verified {
            background: rgba(16, 185, 129, 0.1);
            color: var(--success);
        }
        
        .status-unverified {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
        }
        
        .action-buttons {
            display: flex;
            gap: 8px;
        }
        
        .action-btn {
            width: 32px;
            height: 32px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .edit-btn {
            background: rgba(59, 130, 246, 0.1);
            color: #3b82f6;
        }
        
        .edit-btn:hover {
            background: #3b82f6;
            color: white;
        }
        
        .delete-btn {
            background: rgba(239, 68, 68, 0.1);
            color: var(--error);
        }
        
        .delete-btn:hover {
            background: var(--error);
            color: white;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-row {
            display: flex;
            gap: 20px;
            margin-bottom: 20px;
        }
        
        .form-col {
            flex: 1;
        }
        
        label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text);
        }
        
        input, select, textarea {
            width: 100%;
            padding: 12px 15px;
            border: 1px solid var(--border);
            border-radius: var(--radius);
            font-size: 15px;
            transition: all 0.3s ease;
        }
        
        input:focus, select:focus, textarea:focus {
            border-color: var(--primary);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.2);
            outline: none;
        }
        
        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .checkbox-group input {
            width: auto;
        }
        
        .alert {
            padding: 15px;
            border-radius: var(--radius);
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .alert-success {
            background: rgba(16, 185, 129, 0.1);
            border: 1px solid rgba(16, 185, 129, 0.3);
            color: #047857;
        }
        
        .alert-error {
            background: rgba(239, 68, 68, 0.1);
            border: 1px solid rgba(239, 68, 68, 0.3);
            color: #b91c1c;
        }
        
        /* 响应式设计 */
        @media (max-width: 992px) {
            .sidebar {
                width: 70px;
            }
            
            .logo h2, .nav-links span {
                display: none;
            }
            
            .nav-links a {
                justify-content: center;
                padding: 15px;
            }
            
            .nav-links a i {
                margin-right: 0;
                font-size: 20px;
            }
            
            .main-content {
                margin-left: 70px;
            }
        }
        
        @media (max-width: 768px) {
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            
            .header {
                flex-direction: column;
                align-items: flex-start;
                gap: 15px;
            }
            
            .user-info {
                align-self: flex-end;
            }
            
            .login-wrapper {
                width: 90%;
                max-width: 358px;
                height: auto;
                padding: 40px 30px;
            }
        }
        
        @media (max-width: 576px) {
            .main-content {
                padding: 15px;
            }
            
            .action-buttons {
                flex-direction: column;
            }
        }
    </style>
</head>
<body class="<?php echo isAdminLoggedIn() ? 'admin-logged-in' : ''; ?>">
    <?php if (!isAdminLoggedIn()): ?>
    <!-- 管理员登录表单 -->
    <div class="login-container">
        <div class="login-wrapper">
            <div class="login-header">登录AI后台</div>
            <form method="POST">
                <input type="text" name="username" placeholder="username" class="input-item" required>
                <input type="password" name="password" placeholder="password" class="input-item" required>
                <button type="submit" name="login" class="login-btn">登录</button>
                <?php if ($login_error): ?>
                <div class="error-msg"><?php echo $login_error; ?></div>
                <?php endif; ?>
            </form>
            <div class="msg">
                DeepSeek AI 后台管理系统
            </div>
        </div>
    </div>
    <?php else: ?>
    <!-- 后台主界面 -->
    <div class="sidebar">
        <div class="logo">
            <h2>DeepSeek AI</h2>
        </div>
        <ul class="nav-links">
            <li><a href="admin.php" class="active"><i class="fas fa-users"></i> <span>用户管理</span></a></li>
            <li><a href="admin.php?logout"><i class="fas fa-sign-out-alt"></i> <span>退出登录</span></a></li>
        </ul>
    </div>
    
    <div class="main-content">
        <div class="header">
            <h1>用户管理</h1>
            <div class="user-info">
                <span><?php echo $_SESSION['admin_username']; ?></span>
                <button class="btn btn-outline" onclick="document.getElementById('add-user-form').scrollIntoView()">
                    <i class="fas fa-plus"></i> 添加用户
                </button>
            </div>
        </div>
        
        <?php if (isset($success_message)): ?>
        <div class="alert alert-success">
            <i class="fas fa-check-circle"></i> <?php echo $success_message; ?>
        </div>
        <?php endif; ?>
        
        <?php if (isset($error_message)): ?>
        <div class="alert alert-error">
            <i class="fas fa-exclamation-circle"></i> <?php echo $error_message; ?>
        </div>
        <?php endif; ?>
        
        <div class="card">
            <div class="card-header">
                <h2>用户列表</h2>
                <div class="search-box">
                    <input type="text" placeholder="搜索用户..." style="width: 250px;">
                </div>
            </div>
            <div class="card-body">
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>用户名</th>
                                <th>注册时间</th>
                                <th>Token余额</th>
                                <th>实名状态</th>
                                <th>操作</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($users as $user): ?>
                            <tr>
                                <td><?php echo $user['id']; ?></td>
                                <td><?php echo htmlspecialchars($user['username']); ?></td>
                                <td><?php echo date('Y-m-d', strtotime($user['created_at'])); ?></td>
                                <td><?php echo number_format($user['tokens']); ?></td>
                                <td>
                                    <span class="status-badge <?php echo $user['real_name_verified'] ? 'status-verified' : 'status-unverified'; ?>">
                                        <?php echo $user['real_name_verified'] ? '已认证' : '未认证'; ?>
                                    </span>
                                </td>
                                <td>
                                    <div class="action-buttons">
                                        <a href="admin.php?edit_user=<?php echo $user['id']; ?>" class="action-btn edit-btn">
                                            <i class="fas fa-edit"></i>
                                        </a>
                                        <a href="admin.php?delete_user=<?php echo $user['id']; ?>" class="action-btn delete-btn" onclick="return confirm('确定要删除该用户吗？')">
                                            <i class="fas fa-trash"></i>
                                        </a>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
        
        <!-- 添加/编辑用户表单 -->
        <div class="card" id="add-user-form">
            <div class="card-header">
                <h2><?php echo isset($edit_user) ? '编辑用户' : '添加新用户'; ?></h2>
            </div>
            <div class="card-body">
                <form method="POST">
                    <?php if (isset($edit_user)): ?>
                    <input type="hidden" name="user_id" value="<?php echo $edit_user['id']; ?>">
                    <?php endif; ?>
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="username">用户名</label>
                                <input type="text" id="username" name="username" 
                                    value="<?php echo isset($edit_user) ? htmlspecialchars($edit_user['username']) : ''; ?>" 
                                    required>
                            </div>
                            
                            <div class="form-group">
                                <label for="password">密码</label>
                                <input type="password" id="password" name="password" 
                                    <?php echo !isset($edit_user) ? 'required' : 'placeholder="留空则不更改"'; ?>>
                            </div>
                        </div>
                        
                        <div class="form-col">
                            <div class="form-group">
                                <label for="tokens">Token余额</label>
                                <input type="number" id="tokens" name="tokens" min="0" 
                                    value="<?php echo isset($edit_user) ? $edit_user['tokens'] : '5000'; ?>" 
                                    required>
                            </div>
                            
                            <div class="form-group">
                                <label for="created_at">注册时间</label>
                                <input type="text" id="created_at" 
                                    value="<?php echo isset($edit_user) ? $edit_user['created_at'] : date('Y-m-d H:i:s'); ?>" 
                                    disabled>
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <div class="checkbox-group">
                            <input type="checkbox" id="real_name_verified" name="real_name_verified" 
                                <?php echo (isset($edit_user) && $edit_user['real_name_verified']) ? 'checked' : ''; ?>>
                            <label for="real_name_verified">已实名认证</label>
                        </div>
                    </div>
                    
                    <div class="form-row">
                        <div class="form-col">
                            <div class="form-group">
                                <label for="real_name">真实姓名</label>
                                <input type="text" id="real_name" name="real_name" 
                                    value="<?php echo isset($edit_user['real_name']) ? htmlspecialchars($edit_user['real_name']) : ''; ?>">
                            </div>
                        </div>
                        
                        <div class="form-col">
                            <div class="form-group">
                                <label for="id_card">身份证号</label>
                                <input type="text" id="id_card" name="id_card" 
                                    value="<?php echo isset($edit_user['id_card']) ? htmlspecialchars($edit_user['id_card']) : ''; ?>">
                            </div>
                        </div>
                    </div>
                    
                    <div class="form-group">
                        <button type="submit" name="<?php echo isset($edit_user) ? 'update_user' : 'add_user'; ?>" class="btn btn-primary">
                            <i class="fas fa-save"></i> <?php echo isset($edit_user) ? '更新用户' : '添加用户'; ?>
                        </button>
                        
                        <?php if (isset($edit_user)): ?>
                        <a href="admin.php" class="btn btn-outline">
                            <i class="fas fa-times"></i> 取消
                        </a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </div>
        
        <div class="card">
            <div class="card-header">
                <h2>系统信息</h2>
            </div>
            <div class="card-body">
                <div class="form-row">
                    <div class="form-col">
                        <div class="form-group">
                            <label>系统版本</label>
                            <input type="text" value="DeepSeek AI v2.0" disabled>
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label>用户总数</label>
                            <input type="text" value="<?php echo count($users); ?>" disabled>
                        </div>
                    </div>
                    <div class="form-col">
                        <div class="form-group">
                            <label>Token总量</label>
                            <input type="text" value="<?php echo array_sum(array_column($users, 'tokens')); ?>" disabled>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
</body>
</html>